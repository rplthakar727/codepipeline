#!/bin/bash
systemctl start httpd.service
